//Avas lab assign. 7

var words = "What a day!";

//Preload images and assign variables requirement

var img1
var img2
var img3

function preload(){
  
  img1 = loadImage("bubbles.jpg");
  img2 = loadImage("dogsurf.jpg");
  img3 = loadImage("raccoontransparent.png");
  
}

function setup() {

	createCanvas(600,600);

  //Use the text function to include text requirement
  //choose a system font requirement
  
	textFont("Times Newroman");

	fill(20,200,255);//change the stroke and fill requirement

	stroke(30,40,200);

}


function draw () {

	background(190);

    textSize(30); //include a width and height measurements to limit the area the text will be drawn requirement

	text(words, 400, 400, 200, 400);
  
  
//Use the mouseX and/or mouseY variables to change one of the image's location or image size requirement for one jpg and one png requirement

  image(img1,0,0,mouseX * 4, mouseY * 3);
  image(img2, 200,20,122,50);
  image(img3, 0,mouseY * 2.5);
  


}

